import os
import re
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# Directory with your CSVs
directory = '.'

# Regex pattern: accepts optional 'dedup_' prefix
pattern = re.compile(r'(?:dedup_)?(?P<device>Q1|Q2|Q3|QPro)_merged_v\d+_(?P<date>\d{2}-\d{2}-\d{4})\.csv')

# Store results here
records = []

for filename in os.listdir(directory):
    match = pattern.match(filename)
    if match:
        device = match.group('device')
        date_str = match.group('date')

        try:
            date = datetime.strptime(date_str, '%m-%d-%Y')
        except ValueError:
            continue

        filepath = os.path.join(directory, filename)
        try:
            df = pd.read_csv(filepath)
            # Count binaries where FORTIFY == 'no' (case-insensitive)
            count = (df['FORTIFY'].str.lower() == 'no').sum()
            records.append({'Device': device, 'Date': date, 'NoFORTIFY': count})
        except Exception as e:
            print(f"Error reading {filename}: {e}")

# Convert to DataFrame
plot_df = pd.DataFrame(records)

# Sort by date
plot_df = plot_df.sort_values(by='Date')

# Plotting
plt.figure(figsize=(12, 6))
for device, group in plot_df.groupby('Device'):
    plt.plot(group['Date'], group['NoFORTIFY'], label=device, marker='o')

plt.title("No FORTIFY Found Over Time by Device")
plt.xlabel("Date")
plt.ylabel("Number of Binaries Without FORTIFY")
plt.legend(title="Device")
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

