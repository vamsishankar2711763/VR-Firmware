import os
import re
import matplotlib.pyplot as plt
from datetime import datetime

def expand_config_variant(entry):
    if "{" in entry and "}" in entry:
        base, variant = re.match(r"(.*?)\{(.*?)\}", entry).groups()
        return [base, base + variant]
    return [entry]

def check_flag_presence(content, flag):
    if isinstance(flag, dict) and "require_all" in flag:
        return all(is_flag_enabled(content, f) for f in flag["require_all"])
    elif isinstance(flag, tuple):
        return any(is_flag_enabled(content, f) for f in flag)
    elif "{" in flag:
        variants = expand_config_variant(flag)
        return any(is_flag_enabled(content, v) for v in variants)
    else:
        return is_flag_enabled(content, flag)

def is_flag_enabled(content, flag):
    pattern_enabled = re.compile(rf"^\s*{re.escape(flag)}=y", re.MULTILINE)
    pattern_disabled = re.compile(rf"^\s*#\s*{re.escape(flag)} is not set", re.MULTILINE)
    if pattern_disabled.search(content):
        return False
    return pattern_enabled.search(content) is not None

def analyze_config_file(filepath, config_flags):
    with open(filepath, "r", errors="ignore") as f:
        content = f.read().replace("-", "_")
    missing_flags = []
    for flag in config_flags:
        if not check_flag_presence(content, flag):
            missing_flags.append(str(flag))
    return missing_flags

def scan_q3_configs(directory="."):
    config_flags = [
        ("CONFIG_HAVE_STACKPROTECTOR", "CONFIG_STACKPROTECTOR", "CONFIG_STACKPROTECTOR_STRONG", "CONFIG_CC_STACKPROTECTOR"),
        "CONFIG_RANDOMIZE_BASE",
        "CONFIG_SLAB_FREELIST_RANDOM",
        "CONFIG_HARDENED_USERCOPY",
        ("CONFIG_ARCH_HAS_FORTIFY_SOURCE", "CONFIG_FORTIFY_SOURCE"),
        ("CONFIG_ARCH_HAS_STRICT_KERNEL_RWX", "CONFIG_DEBUG_RODATA"),
        ("CONFIG_CPU_SW_DOMAIN_PAN", "CONFIG_ARM64_SW_TTBR0_PAN"),
        "CONFIG_UNMAP_KERNEL_AT_EL0",
        "CONFIG_CFI_CLANG",
        ("CONFIG_SHADOW_CALL_STACK","CONFIG_ARCH_SUPPORTS_SHADOW_CALL_STACK","CONFIG_CC_HAVE_SHADOW_CALL_STACK"),
        ("CONFIG_INIT_STACK_ALL", "CONFIG_INIT_STACK_ALL_ZERO"),
        "CONFIG_INIT_ON_ALLOC_DEFAULT_ON",
        "CONFIG_DEBUG_LIST",
        "CONFIG_BPF_JIT_ALWAYS_ON",
        "CONFIG_SLAB_FREELIST_HARDENED",
        "CONFIG_VMAP_STACK",
        "CONFIG_ARM64_UAO"
    ]

    dates_q1 = []
    mitigations_q1 = []
    dates_q2 = []
    mitigations_q2 = []
    dates_q3 = []
    mitigations_q3 = []
    dates_qpro = []
    mitigations_qpro = []

    for filename in sorted(os.listdir(directory)):
        print(f"Processing file: {filename}")  # Debug print to see what file is being processed
        
        # Match filenames starting with q1, q2, q3, and QPro in the format <prefix>_v<version>_<date>
        match_q1 = re.match(r"q1_v\d+_(\d{2}-\d{2}-\d{4})", filename)
        match_q2 = re.match(r"q2_v\d+_(\d{2}-\d{2}-\d{4})", filename)
        match_q3 = re.match(r"q3_v\d+_(\d{2}-\d{2}-\d{4})", filename)
        match_qpro = re.match(r"QPro_v\d+_(\d{2}-\d{2}-\d{4})", filename)

        if match_q1:
            date_str = match_q1.group(1)  # Extract date from filename, e.g. "06-23-2024"
            date_obj = datetime.strptime(date_str, "%m-%d-%Y")  # Convert string to date object
            path = os.path.join(directory, filename)
            missing = analyze_config_file(path, config_flags)
            print(f"Q1 file: {filename}, Missing Flags: {missing}")  # Debug print
            dates_q1.append(date_obj)
            mitigations_q1.append(len(config_flags) - len(missing))  # Number of mitigations applied is total flags minus missing flags

        elif match_q2:
            date_str = match_q2.group(1)  # Extract date from filename, e.g. "06-23-2024"
            date_obj = datetime.strptime(date_str, "%m-%d-%Y")  # Convert string to date object
            path = os.path.join(directory, filename)
            missing = analyze_config_file(path, config_flags)
            print(f"Q2 file: {filename}, Missing Flags: {missing}")  # Debug print
            dates_q2.append(date_obj)
            mitigations_q2.append(len(config_flags) - len(missing))  # Number of mitigations applied is total flags minus missing flags

        elif match_q3:
            date_str = match_q3.group(1)  # Extract date from filename, e.g. "06-23-2024"
            date_obj = datetime.strptime(date_str, "%m-%d-%Y")  # Convert string to date object
            path = os.path.join(directory, filename)
            missing = analyze_config_file(path, config_flags)
            print(f"Q3 file: {filename}, Missing Flags: {missing}")  # Debug print
            dates_q3.append(date_obj)
            mitigations_q3.append(len(config_flags) - len(missing))  # Number of mitigations applied is total flags minus missing flags

        elif match_qpro:
            date_str = match_qpro.group(1)  # Extract date from filename, e.g. "06-23-2024"
            date_obj = datetime.strptime(date_str, "%m-%d-%Y")  # Convert string to date object
            path = os.path.join(directory, filename)
            missing = analyze_config_file(path, config_flags)
            print(f"QPro file: {filename}, Missing Flags: {missing}")  # Debug print
            dates_qpro.append(date_obj)
            mitigations_qpro.append(len(config_flags) - len(missing))  # Number of mitigations applied is total flags minus missing flags

    return dates_q1, mitigations_q1, dates_q2, mitigations_q2, dates_q3, mitigations_q3, dates_qpro, mitigations_qpro

# Add functionality to plot mitigations with predefined change over time
def plot_mitigations():
    # Define date changes for mitigations (and extend the line)
    start_date = datetime(2019, 1, 1)  # Start at the beginning of the graph
    end_date = datetime(2025, 1, 1)  # Extend the line to 2025
    dates = [
        start_date,  # Start of the graph
        datetime(2019, 7, 7),  # First change point (15 to 16)
        datetime(2019, 9, 15),  # Second change point (16 to 17)
        end_date  # End of the graph (2025)
    ]
    mitigations = [15, 16, 17, 17]  # Mitigations over time

    # Plotting the line with extended range and custom color
    plt.plot(dates, mitigations, label="Mitigations Present", color='purple', marker='o', linestyle='-', linewidth=2)

# Get data and plot the graph
dates_q1, mitigations_q1, dates_q2, mitigations_q2, dates_q3, mitigations_q3, dates_qpro, mitigations_qpro = scan_q3_configs(".")
print(f"Q1 Dates: {dates_q1}")
print(f"Q1 Mitigations: {mitigations_q1}")
print(f"Q2 Dates: {dates_q2}")
print(f"Q2 Mitigations: {mitigations_q2}")
print(f"Q3 Dates: {dates_q3}")
print(f"Q3 Mitigations: {mitigations_q3}")
print(f"QPro Dates: {dates_qpro}")
print(f"QPro Mitigations: {mitigations_qpro}")

# Ensure the dates are sorted in chronological order for all categories
sorted_dates_q1, sorted_mitigations_q1 = zip(*sorted(zip(dates_q1, mitigations_q1)))
sorted_dates_q2, sorted_mitigations_q2 = zip(*sorted(zip(dates_q2, mitigations_q2)))
sorted_dates_q3, sorted_mitigations_q3 = zip(*sorted(zip(dates_q3, mitigations_q3)))
sorted_dates_qpro, sorted_mitigations_qpro = zip(*sorted(zip(dates_qpro, mitigations_qpro)))

# Plotting the data with a line plot (connects the data points in chronological order)
plt.figure(figsize=(10, 6))

# Plot the mitigations line (color changed to purple)
plot_mitigations()

# Plot Q1 data with a line in blue
plt.plot(sorted_dates_q1, sorted_mitigations_q1, color='b', label='Q1 Mitigations Applied', marker='o')
# Plot Q2 data with a line in orange
plt.plot(sorted_dates_q2, sorted_mitigations_q2, color='orange', label='Q2 Mitigations Applied', marker='o')
# Plot Q3 data with a line in green
plt.plot(sorted_dates_q3, sorted_mitigations_q3, color='g', label='Q3 Mitigations Applied', marker='o')
# Plot QPro data with a line in red
plt.plot(sorted_dates_qpro, sorted_mitigations_qpro, color='r', label='QPro Mitigations Applied', marker='o')

plt.xticks(rotation=45)  # Rotate x-axis labels for better readability

# Adjust the x-axis to show only years
plt.gca().xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%Y'))
plt.gca().xaxis.set_major_locator(plt.matplotlib.dates.YearLocator())  # Show a tick for each year

plt.xlabel('Year')
plt.ylabel('Number of Mitigations Applied')
plt.title('Mitigations Applied Over Time')
plt.tight_layout()
plt.legend()
plt.show()

